import spec
import cars


spec.gen_module(cars)
