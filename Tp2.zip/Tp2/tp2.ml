


 (*Question 1.1*)


let rec integers n = 
  match n with 
  | 0-> [0] 
  | n -> integers(n-1) @ [n] ;;

(*Question 1.2*)
let rec integers1 n =
  match n with 
  | 0-> [0] 
  | n -> List.rev (  integers1 (n-1)@ [n] ) ;;

(*Question 1.3*)
let rec integers2 n =
  
  match n with 
  | 0-> [0] 
  | n -> n :: integers2 (n-1) ;;

(*Question 1.4*)
let time f x =
  let t = Sys.time() in 
  let resultat = f x in 
  (Sys.time() -. t) *. 1000. , resultat ;;




(* # time integers 6;;
- : float * int list = (0.00899999999999512301, [0; 1; 2; 3; 4; 5; 6])
# time integers2 6;;
- : float * int list = (0.00899999999999512301, [0; 1; 2; 3; 4; 5; 6])
# time integers3 6;;
- : float * int list = (0.008000000000008, [0; 1; 2; 3; 4; 5; 6]) ----- la plus rapide *)


(*Question 2.1*)        
  
let  rec size l = 
  match l with 
  | [] -> 0
  | [x] -> 1
  | x::xs -> 1 + size (xs) ;;


(*Question 2.2*)  
let three_or_more1 l = if size (l) >= 3 then true else false;;

let three_or_more l = 
  match l with 
  | l -> if size(l) >= 3 then true else false ;;

(*Question 2.3*)  
let last l =
  match l with 
  |[] -> failwith "vide"
  |[x] -> x
  | l -> List.hd (List.rev(l)) ;;



let rec last1 l =
  match l with 
  | [] -> failwith"vide" 
  | [x] -> x
  |x::xs -> last1 (xs);;

(*Question 2.4*)  
let rec sum l =
  match l with 
  |[] -> 0
  |[x] -> x
  |x::xs -> x + sum(xs);;

(*Question 2.5*)  
let  find  e l =
  match l with 
  |[] -> failwith " vide" 
  |x::xs -> if x= e then true else false;;

(*Question 2.6*) 
let rec nth  n l =
  match  l with
  | [] -> failwith "vide"
  | x::xs -> if n = 0 then x else nth (n-1) xs ;;


(*Question 2.7*) 
let  is_increasing l =
  
  match l with
  | [] -> failwith " vide " 
  | x::xs -> if x< List.hd (xs)  then true else false ;;

(*Question 2.9*) 
let rec max_list l =
  
  match l with 
  |[] -> 0 
  |[x] -> x 
  | l -> if (is_increasing l) then last l else if List.hd(l) < List.hd (List.tl(l)) then max_list (List.tl(l)) else List.hd(l);;


(*Question 3.1*) 
let list_copy l =
  match l with 
  |[] -> []
  |[x] -> [x]
  |x::xs -> x:: xs ;;

(*Question 3.2*) 
let rec reverse l = 
  match l with 
  |[] -> [] 
  |[x] -> [x] 
  | x::xs ->  reverse xs @ [x] ;;

(*Question 3.3*) 
let rec flatten_list l = 
  match l with 
  |[] -> []
  |x::xs -> x @flatten_list xs ;;


(*Question 3.4*) 
let rec without_duplicates m =
  match m with 
  |[] -> []
  |x::y::xs -> if  x==y then y::(without_duplicates xs) else without_duplicates (y::xs)
  |_::_ ->failwith "vide";;
 
              

(*Question 4.1*) 
let rec filter f l = 
  match l with 
  |[]-> failwith " list_vide" 
  | x::xs ->  if (f x ) then x::(filter f xs) else filter f xs ;;
   
   
(*Question 4.4*) 
let  rec includes e l = 
  match l with 
  |[]-> false
  |x::xs -> if e == x then true else includes e xs ;;


(*Question 4.5*) 
let  rec including l1 l2 = 
  match l1,l2 with 
  |[],[] -> false 
  |(x::xs),(e::f) -> if x==e then true else including xs f 
  |_,_ -> failwith"vide" ;;
    


(*Question 4.6*) 
let  rec includes e l = 
  match l with 
  |[]-> true
  |x::xs -> if e == x then false else includes e xs ;;

  

(*Question 4.7*)     
let  rec including l1 l2 = 
  match l1,l2 with 
  |[],[] -> true
  |(x::xs),(e::f) -> if x==e then false else including xs f 
  |_,_ -> failwith " vide" ;;


(*Question 4.8*)   

let rec zip l1 l2 =
  match l1,l2 with 
  |[],[] -> [] 
  |x::xs, e::f-> (x,e)::zip xs f
  |_,_ -> failwith"vide" ;;
 

(*Question 5.2*)
(* #[1; 2; 3; 4] |> List.filter (fun x -> x mod 2 = 0) ;;
- : int list = [2; 4] *)
 
   
(*Question 5.3*)  
let renverse l =
  let rec aux li resu = match li with
    |[] -> resu
    |t::q -> aux q (t::resu)
  in aux l [];;
    
     
let rec pair_inverse l =
  match l with 
  |[] -> []
  | x::xs -> if x mod 2 = 0 then renverse  (x::pair_inverse xs)  else renverse(pair_inverse xs )



(*Question 5.4*)
let nb_impaire l =
  let rec nb l cpt= 
    match l with 
    | [] -> cpt
    |x::xs-> if x mod 2 !=0 then nb xs cpt+1  else nb xs cpt
  in nb l 0 ;;
              
(*Question 5.6*)
let rec carre l =
  match l with 
  |[] -> []
  |x::xs-> if  x mod 2 != 0 then (x*x)::(carre xs) else carre xs;;

(*Question 6.1*)           
let rec split l=
  match l with
  |[]->[],[]
  |a::[]->l,[]
  |a::b::c->
      let (l1,l2)=split c in
      a::l1,b::l2;;



(*Question 6.2*)

let rec merge l1 l2=
  match l1,l2 with
  |[],_->l2;
  |_,[]->l1;
  |t1::q1,t2::q2->
      if t1<t2 then
        t1::(merge q1 l2)
      else
        t2::(merge l1 q2);;



(*Question 6.3*)  

let rec fusion_sort l=
  match l with
  |[]->[];
  |a::[]->l;
  |_ ->
      begin
        let (l1,l2)=split l in
        merge(fusion_sort(l1)) (fusion_sort(l2));
      end;;
