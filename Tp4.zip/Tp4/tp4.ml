(* question 1*)

type malt = Values of  int 
          |Binop of string*malt*malt 
          |Uniop of string*malt ;;


(* question 2*)
let a = Binop("+",Values(1),Binop("+",Values(2),Values(-3)));;



(* question 3*)
let rec evaluate_exp malt =
  match malt with 
  | Binop ("+",a,b) -> (evaluate_exp a) + ( evaluate_exp b)
  | Binop ("-",a,b) -> (evaluate_exp  a) - (evaluate_exp b)
  | Binop ("/",a,b) -> (evaluate_exp a) / (evaluate_exp b)
  | Binop ("*",a,b) -> (evaluate_exp a) * (evaluate_exp b)
  | Binop (_,_,_ )-> failwith  "error" 
  | Values (x) -> x 
  | Uniop ("+",a) -> (evaluate_exp a) 
  | Uniop ("-",a) -> (evaluate_exp  a) 
  | Uniop ("/",a) -> (evaluate_exp a) 
  | Uniop ("*",a) -> (evaluate_exp a) 
  | Uniop (_,_ )-> failwith  "error" ;; 


(*exo 2*)
(* question 1*) 


let list = [("+",(+));("-",(-));("/",(/));("*",( * ))];;


(* question 2*)
let rec search op list = 
  match list with 
  | [] -> failwith "error" 
  | x::xs -> if fst (x) = op  then snd (x) else search op xs 
  

(* question 3*)


let rec evaluate_epx n l = 
  match n with 
  | Values x -> x
  | Binop(op,a,b) -> (search op l) (evaluate_exp) (evaluate_exp b )
  | Uniop ("-",a) -> (evaluate_exp a )
  | Uniop (_,_)-> raise(failwith "error") ;;


(* question 4*)
let rec exp x n = 
  match n with
  |0 ->1 
  |1-> n 
  |n -> x*(exp x (n-1)) ;;





(*exo 3*)
(*  Question 1. *)
type expr = Valeur of int | Binaire of (string * expr * expr) | Unaire of (string * expr) | Var of string;;

type statement = Expression of expr | Affectation of (string * expr);;


(*  Question 3. *)

let example2 = Affectation ("a",Binaire("+",Valeur 6,Binaire("*",Valeur 4,Valeur 5)));;




(*  Question 4. *)
(*

on peut creer un liste des couples qui contient à chaque fois le nom de la variable "string" et sa valeur "int"

let environnement = [("a",int)]
*)





(*  Question 5. *)

(* Oui, on peut utiliser la fonction qui recherche une opération, en changeant l'opérateur par le nom de la variable et le model par l'environnement
*)

let environnement = [("a",5);("b",6)];;
let findValue a env = findFonction a env;;

let rec evaluate_expr2 listExpre expr env= match expr with
| Valeur v -> v
| Binaire(op,a,b) ->  (findFonction op listExpre) (evaluate_expr2 listExpre a env) (evaluate_expr2 listExpre b env)
| Unaire (op,a) when op = "-" -> -1*(evaluate_expr2 listExpre a env)
| Unaire _ -> failwith "negative operation expected"
| Var x -> findValue x env;;

(*  Question 6. *)

let evaluate_Affectation v e env = (v,(evaluate_expr2 model e env))::env;;

let evaluate_expr3 e env= evaluate_expr2 model e env;;

let evaluate_statement statement env = match statement with
| Expression e -> (evaluate_expr3 e env,env)
| Affectation (s,e) -> (evaluate_expr3 e env,evaluate_Affectation s e env);;



(*exo4*)

(*  Question 1. *)
type statements = Statement of statement | Sequence of (statement * statements);;

(*  Question 2. *)

let example3 = Sequence(Affectation("a",Binaire("+",Valeur 4,Valeur 5)),Sequence(Affectation("b",Binaire("+",Var "a",Valeur 1)),Statement(Expression(Binaire("+",Var "a",Var "b")))));;


(*  Question 3. *)

let rec evaluate_matL seq env=match seq with
| Statement s -> fst (evaluate_statement s env)
| Sequence(s,stmts) -> evaluate_matL stmts (snd (evaluate_statement s env));;




                    
