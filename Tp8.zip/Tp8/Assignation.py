class Assignation(Statement):

    def __init__(self,variable,expression):
        self.var=var
        self.expr=expression
