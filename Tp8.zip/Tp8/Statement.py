class Statement:
    pass
