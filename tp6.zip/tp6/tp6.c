#include <stdlib.h>
#include <stdio.h>
#include <string.h>



typedef struct{
    int numero;
    char  nom[50];
    int credit;
    
}Compte;


Compte * create_compte(int a, char c[], int b ){
    Compte *n;
    n= malloc(sizeof(Compte));
    n ->numero=n;
    strcpy(c ->nom,c);*
    n -> credit = b;
    return n;



}


//question4 : free();

void add (Compte *a, int n){
    a ->credit+= n;

}

//question6:

void retirer(Compte *a, int n){
     a ->credit = a->credit - n;
}


int main(){
    Compte *a;
    a = create_compte(30,"razika",2);
    add(a,1200);
    printf("%s\n" , a ->nom);
    printf("%s\n" , a ->credit);

    free(a);



}




